from django.shortcuts import render, redirect
import random


def index(request):
    if 'results' not in request.session:
        request.session['results'] = []
    if 'gold' not in request.session:
        request.session['gold'] = 0
    gold = request.session['gold']
    context = {
        'gold': gold,
        'results': request.session['results']
    }
    return render(request, "index.html", context)


def process_money(request):
    if request.method == 'POST':
        if request.POST['which_form'] == 'farm_form':
            rando = random.randint(10, 20)
            request.session['gold'] += rando
            request.session['results'].append(
                f"Earned {rando} golds from the Farm!")

        elif request.POST['which_form'] == 'cave_form':
            rando = random.randint(5, 10)
            request.session['gold'] += rando
            request.session['results'].append(
                f"Earned {rando} golds from the Cave!")

        elif request.POST['which_form'] == 'house_form':
            rando = random.randint(2, 5)
            request.session['gold'] += rando
            request.session['results'].append(
                f"Earned {rando} golds from the house!")

        elif request.POST['which_form'] == 'casino_form':
            rando = random.randint(-50, 50)
            request.session['gold'] += rando
            if rando > 0:
                request.session['results'].append(
                    f"Entered a casino and won {rando} golds!")
            else:
                request.session['results'].append(
                    f"Entered a casino and lost {rando * -1} golds...Ouch...")

    return redirect('/')


def reset(request):
    request.session.clear()
    return redirect('/')
